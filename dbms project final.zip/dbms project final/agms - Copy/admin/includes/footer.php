 <div class="text-right">
        <div class="credits">
        <p>Brandz Photography</p>
        </div>
      </div>