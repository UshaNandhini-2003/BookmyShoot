<aside>
      <div id="sidebar" class="nav-collapse ">
        <!-- sidebar menu start-->
        <ul class="sidebar-menu">
          <li class="active">
            <a class="" href="dashboard.php">
                          <i class="icon_house_alt"></i>
                          <span>Dashboard</span>
                      </a>
          </li>
          

<li class="sub-menu">
            <a href="javascript:;" class="">
                          <i class="icon_genius"></i>
                          <span>Enquiry form</span>
                          <span class="menu-arrow arrow_carrot-right"></span>
                      </a>
            <ul class="sub">
              <!--<li><a class="" href="aboutus.php"><span>About Us</span></a></li>-->
              <li><a class="" href="view-enquiry.php"><span>View Enquiry</span></a></li>
              
            </ul>
          </li>


          <!--<li class="sub-menu">
            <a href="javascript:;" class="">
                          <i class="icon_documents_alt"></i>
                          <span>Pages</span>
                          <span class="menu-arrow arrow_carrot-right"></span>
                      </a>
            <ul class="sub">
              <li><a class="" href="aboutus.php"><span>About Us</span></a></li>
              <li><a class="" href="contactus.php"><span>Contact Us</span></a></li>
              
            </ul>
          </li>-->

        
        <!-- sidebar menu end-->
      </div>
    </aside>